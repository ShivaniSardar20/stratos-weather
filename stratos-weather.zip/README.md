# Stratos Weather 🌦️

Stratos Weather is a next-generation intelligent weather dashboard that combines precise meteorological data with AI-driven insights. Powered by Open-Meteo and Google Gemini, it offers a visually immersive experience that adapts to current weather conditions.

## ✨ Features

- **Real-Time Weather**: Accurate current conditions including temperature, wind speed, humidity, and more.
- **AI Insights**: Context-aware weather advice and witty commentary powered by Google Gemini 2.5 Flash.
- **Dynamic Themes**: The application background and ambient effects shift dynamically based on weather conditions (rain, snow, clear sky, etc.) and time of day.
- **Interactive Map**: A built-in map view (Leaflet) pinpointing the location with a custom marker and live tooltip.
- **24-Hour Forecast**: Interactive area chart visualizing temperature trends for the next day.
- **7-Day Outlook**: Detailed daily forecast with high/low temperatures and weather icons.
- **Location Search**: Autocomplete search bar for cities worldwide, plus geolocation support.

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript
- **Styling**: Tailwind CSS
- **AI**: Google GenAI SDK (`gemini-2.5-flash`)
- **Data**: Open-Meteo API (Weather & Geocoding)
- **Visualization**: Recharts (Charts), Leaflet (Maps)
- **Icons**: Lucide React

## 🚀 Getting Started

### Prerequisites

- Node.js installed.
- A Google Gemini API Key.

### Installation

1. **Clone the repository**

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure Environment**
   - You need a valid API key for Google Gemini.
   - Ensure `process.env.API_KEY` is available in your build/runtime environment.

4. **Run the application**
   ```bash
   npm start
   ```

## 🔮 How it Works

1.  **Weather Data**: The app fetches latitude/longitude coordinates using the Open-Meteo Geocoding API, then retrieves detailed weather data from the Open-Meteo Forecast API.
2.  **AI Analysis**: The gathered weather metrics are formatted into a context string and sent to the Gemini model. The model generates a short, fun, and practical insight.
3.  **Visuals**: The `CurrentWeather`, `WeatherMap`, and `ForecastChart` components render the data. The `App` component calculates dynamic gradients and animation speeds based on the weather code and wind speed.

## 📄 License

This project is open source and available for educational purposes.